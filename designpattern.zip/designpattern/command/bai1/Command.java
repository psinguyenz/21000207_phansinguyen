package designpattern.command.bai1;

public interface Command {
    void execute();
}
