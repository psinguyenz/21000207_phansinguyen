package designpattern.bridge.bai1;

public interface OperatingSystem {
    void startup();
    void loadUrl(String url);
}
