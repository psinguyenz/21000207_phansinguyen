package designpattern.visitor.bai2;

public class ComputerPartDisplayVisitor implements ComputerPartVisitor{
    @Override
    public void visit(Mouse mouse) {

    }

    @Override
    public void visit(Monitor monitor) {

    }

    @Override
    public void visit(Computer computer) {

    }

    @Override
    public void visit(Keyboard keyboard) {

    }
}
