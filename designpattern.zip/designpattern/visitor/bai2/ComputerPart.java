package designpattern.visitor.bai2;

public interface ComputerPart {
    void accept();
}
