package designpattern.visitor.bai2;

public class Computer implements ComputerPart{
    public Computer() {

    }

    @Override
    public void accept() {

    }
}
