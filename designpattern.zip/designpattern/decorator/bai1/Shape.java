package designpattern.decorator.bai1;

public interface Shape {
    void draw();
}
