package designpattern.decorator.bai1;

public class Circle implements Shape{
    @Override
    public void draw() {
        System.out.print("Draw Circle");
    }
}
