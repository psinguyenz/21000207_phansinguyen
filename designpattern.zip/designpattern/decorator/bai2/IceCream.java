package designpattern.decorator.bai2;

public interface IceCream {
    String getDescription();
}
