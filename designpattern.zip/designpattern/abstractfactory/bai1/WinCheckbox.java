package abstractfactory.bai1;

public class WinCheckbox implements Checkbox {

    @Override
    public void paint() {
        System.out.println("You have created WinCheckbox.");
    }
}
