package abstractfactory.bai1;

public interface GUIFactory {
    Button createButton();
    Checkbox createCheckbox();
}
