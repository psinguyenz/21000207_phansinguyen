package abstractfactory.bai1;

public interface Button {
    void paint();
}
