package abstractfactory.bai2;

public abstract class Shape {
    public abstract void draw();
}
