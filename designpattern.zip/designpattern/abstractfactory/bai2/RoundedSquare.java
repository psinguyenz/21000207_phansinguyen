package abstractfactory.bai2;

public class RoundedSquare extends Shape{
    @Override
    public void draw() {
        System.out.println("Draw Rounded Square!");
    }
}
