package abstractfactory.bai2;

public class Square extends Shape{
    @Override
    public void draw() {
        System.out.println("Draw Square!");
    }
}
