package factorymethod.bai2.factorysimple;

public interface Fruit {
    void produceJuice();
}
