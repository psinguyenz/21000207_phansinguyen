package factorymethod.bai2.factorysimple;

public class Orange implements Fruit{
    @Override
    public void produceJuice() {
        System.out.println("Orange Juice");
    }
}
