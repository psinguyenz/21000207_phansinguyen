package factorymethod.bai2.factorysimple;

public class Apple implements Fruit{
    @Override
    public void produceJuice() {
        System.out.println("Apple juice");
    }
}
