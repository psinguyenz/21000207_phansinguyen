package factorymethod.bai2.factorysimple;

public class Banana implements Fruit{
    @Override
    public void produceJuice() {
        System.out.println("Banana Juice");
    }
}
