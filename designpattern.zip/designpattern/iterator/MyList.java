package com.iterator;

import java.util.ArrayList;

public class MyList implements MyIterable {
	private ArrayList<String> menuItems;
 
	public MyList() {
		menuItems = new ArrayList<String>();
	}

	public void addItem(String name) {
		/* TODO */
	}
 
	public ArrayList<String> getMenuItems() {
		/* TODO */
		return null;
	}
  
	public Iterator createIterator() {
		/* TODO */
		return null;
	}
  
	public String toString() {
		/* TODO */
		return "";
	}
}
