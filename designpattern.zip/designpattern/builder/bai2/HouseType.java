package designpattern.builder.bai2;

public enum HouseType {
    APARTMENT, VILLAS, STUDIO
}
