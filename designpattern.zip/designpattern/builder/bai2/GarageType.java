package designpattern.builder.bai2;

public enum GarageType {
    WITH_GARAGE, NO_GARAGE
}
