package designpattern.builder.bai2;

public enum SwimmingPoolType {
    ROUND_SWIMMINGPOOL, SQUARE_SWIMMINGPOOL, NO_SWIMMINGPOOL
}
