package designpattern.builder.bai2;

public enum GardenType {
    BIG_GARDEN, SMALL_GARDEN, NO_GARDEN
}
