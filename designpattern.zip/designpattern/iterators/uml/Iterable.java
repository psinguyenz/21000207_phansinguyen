package designpattern.iterators.uml;

public interface Iterable {
    Iterator iterator();
}
